from sage.all import *
from lib.maps import (
    temper_map,
    merge_396_623_map,
    untemper_map
)
from lib.symexprs import oi

t = oi(396) + oi(623)
t = t(temper_map(396))(temper_map(623))
t = t(merge_396_623_map(0))
t = t(untemper_map(0))
# print(t)

W_columns = [ t[f'O{0}_{i}'] for i in range(32) ]
W = Matrix(GF(2), W_columns).T
r = vector(GF(2), t['S-1_31'])

# print(W)
# print(r)
