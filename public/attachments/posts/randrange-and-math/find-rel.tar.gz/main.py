from lib.maps import (
    temper_map,
    merge_396_623_map,
    untemper_map
)
from lib.symexprs import oi

l = 32
t = oi(396) + oi(623)
t = t(temper_map(396))(temper_map(623))
t = t(merge_396_623_map(0))
t = t(untemper_map(0))[-l:]

print(t)
