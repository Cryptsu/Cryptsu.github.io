import os

from sage.all import load

from .encodings import int2vec

DIR = os.path.dirname(__file__)

# Temper matrix
T    = load(DIR + "/T.sobj")
Tinv = T**-1

# Special vector
a = int2vec(0x9908B0DF, 32)
