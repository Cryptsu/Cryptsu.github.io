from sage.all import GF, identity_matrix
from sage.structure.element import (
    Matrix as MatrixType,
)

from .symbols import generate_output_varnames
from .VectorExpr import VectorExpr

GF2 = GF(2)

def Moi(M, i, partial=None):
    assert isinstance(M, MatrixType)
    assert M.base_ring() == GF2
    
    oi1 = generate_output_varnames(i)

    coef_map = {}
    if partial is None:
        partial = range(32)
    for b in partial:
        coef_map[oi1[b]] = M.T[b]

    return VectorExpr(coef_map)

def oi(i):
    I = identity_matrix(GF2, 32)
    return Moi(I, i)

def msb_Moi(M, i, l):
    assert isinstance(M, MatrixType)
    assert M.base_ring() == GF2
    
    oi1 = generate_output_varnames(i)

    coef_map = {}
    for b in range(32-l, 32):
        coef_map[oi1[b]] = M.T[b - (32-l)]

    return VectorExpr(coef_map)
