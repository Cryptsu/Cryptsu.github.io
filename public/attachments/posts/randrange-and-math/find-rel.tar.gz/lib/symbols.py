def generate_state_varnames(i):
    return [f"S{i}_{b}" for b in range(32)]

def generate_output_varnames(i):
    return [f"O{i}_{b}" for b in range(32)]

