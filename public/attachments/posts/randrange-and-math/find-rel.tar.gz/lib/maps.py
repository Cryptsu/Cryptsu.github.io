from .IntExpr import IntExpr
from .mathobjs import T, Tinv, a
from .symbols import (
    generate_output_varnames,
    generate_state_varnames,
)


def merge_396_623_map(i, mode="396_623"):
    if mode not in ["1_396", "396_623", "1_623"]:
        raise ValueError("only accept merge modes: 1_396, 396_623, 1_623")
    
    si0 = generate_state_varnames(i)
    si_1 = generate_state_varnames(i-1)
    si396 = generate_state_varnames(i+396)
    si623 = generate_state_varnames(i+623)

    repl_map = {}
    for b in range(30):
        lhs = IntExpr({
            si396[b]: 1,
            si623[b]: 1,
        })
        rhs = IntExpr({
            si0[b+1]: 1,
            si0[0]: a[b]
        })
        repl_map[lhs] = rhs

    # b = 30
    lhs = IntExpr({
        si396[30]: 1,
        si623[30]: 1,
    })
    rhs = IntExpr({
        si_1[31]: 1,
        si0[0]: a[30]
    })
    repl_map[lhs] = rhs
    
    # b = 31
    lhs = IntExpr({
        si396[31]: 1,
        si623[31]: 1,
    })
    rhs = IntExpr({
        si0[0]: a[31]
    })
    repl_map[lhs] = rhs

    return repl_map

def temper_map(i):
    oi1 = generate_output_varnames(i)
    si1 = generate_state_varnames(i)
    
    repl_map = {}
    for b in range(32):
        lhs = IntExpr({oi1[b]: 1})
        rhs = IntExpr({
            si1[rb]: T.T[rb,b]
                for rb in range(32)
        })
        repl_map[lhs] = rhs
        
    return repl_map

def untemper_map(i):
    oi1 = generate_output_varnames(i)
    si1 = generate_state_varnames(i)
    
    repl_map = {}
    for b in range(32):
        lhs = IntExpr({si1[b]: 1})
        rhs = IntExpr({
            oi1[rb]: Tinv.T[rb,b]
                for rb in range(32)
        })
        repl_map[lhs] = rhs
        
    return repl_map
