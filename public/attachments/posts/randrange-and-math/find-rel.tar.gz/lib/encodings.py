from sage.all import GF, vector


def int2vec(state, l=32):
    v = []
    for _ in range(l):
        v.append(state & 0x1)
        state >>= 1
    return vector(GF(2), v)

def vec2int(v):
    return int(''.join(map(str, v))[::-1], 2)
