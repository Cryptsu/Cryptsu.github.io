from sage.all import GF, zero_vector
from sage.structure.element import (
    Matrix as MatrixType,
    Vector as VectorType,
)

from .IntExpr import IntExpr

GF2 = GF(2)

class VectorExpr:
    def __init__(self, coef_map: dict[str, VectorType] = {}):
        self.coef_map = {}
        
        if len(coef_map) != 0:
            dim0 = len(list(coef_map.values())[0])
        else:
            dim0 = 0
                
        for var, coef in coef_map.items():
            if coef == 0:
                continue
            if not isinstance(coef, VectorType) or coef.base_ring() != GF2:
                raise ValueError(f"coef must be VectorType in GF(2), got {type(coef)}")
            if len(coef) != dim0:
                raise ValueError("each coef doesn't have the same dimension")
            self.coef_map[var] = coef

        if len(self.coef_map) == 0:
            self.dim = 0
        else:
            self.dim = dim0

    @property
    def vecs(self):
        return list({ str(c): c for v, c in self.coef_map.items() }.values())

    @property
    def vars(self):
        return list(self.coef_map.keys())

    @property
    def is_const(self):
        return self.vars == ['1'] or len(self.vars) == 0
    
    def __add__(self, other: 'VectorExpr'):
        if not isinstance(other, VectorExpr):
            raise ValueError(f"adding VectorExpr with non VectorExpr (got {type(other)}) is not allowed")
        if self.dim == 0:
            return VectorExpr(other.coef_map)
        if other.dim == 0:
            return VectorExpr(self.coef_map)
        if self.dim != other.dim:
            raise ValueError(f"dim mismatch: {self.dim = } != {other.dim = }")

        sum_map = {}
        for var, coef in self.coef_map.items():
            sum_map[var] = coef
        for var, coef in other.coef_map.items():
            sum_map[var] = sum_map.get(var, 0) + coef

        return VectorExpr(sum_map)

    def __sub__(self, other: 'VectorExpr'):
        return self.__add__(other)
        
    def __mul__(self, other: int):
        try:
            other = GF2(other)
        except TypeError:
            raise TypeError(f"other must be int-like, got {type(other)}")
        return self.__rmul__(other)
        
    def __rmul__(self, other: MatrixType | int):
        if isinstance(other, MatrixType):
            if other.base_ring() != GF2:
                raise ValueError(f"left-multiply with non GF(2) matrix: got ring={other.base_ring()}")
            if other.dimensions()[1] != self.dim:
                raise ValueError(f"matrix dim incompatible: {self.dim = }, while {other.dimensions() = }")
        else: # must be int or int-like :P
            try:
                other = GF2(other)
            except TypeError:
                raise TypeError(f"other must be int-like or matrix-like, got {type(other)}")

        updated_map = {}
        for var, coef in self.coef_map.items():
            updated_map[var] = other * coef

        return VectorExpr(updated_map)

    def __or__(self, other: 'VectorExpr'):
        if not isinstance(other, VectorExpr):
            raise ValueError(f"or-ing VectorExpr with non VectorExpr (got {type(other)}) is not allowed")

        if self.dim == 0:
            return VectorExpr(other.coef_map)
        if other.dim == 0:
            return VectorExpr(self.coef_map)

        concat_map = {}
        for var, coef in self.coef_map.items():
            if var not in other.coef_map:
                concat_map[var] = coef.concatenate(zero_vector(GF2, other.dim))
            else:
                concat_map[var] = coef.concatenate(other.coef_map[var])
                
        for var, coef in other.coef_map.items():
            if var not in self.coef_map:
                concat_map[var] = zero_vector(GF2, self.dim).concatenate(coef)

        return VectorExpr(concat_map)
            

    def __getitem__(self, key):
        if isinstance(key, slice):
            if self.dim == 0:
                return
                
            a, b, step = key.indices(self.dim)
            if step != 1:
                raise ValueError("Step != 1 not supported")
                
            new_dim = b - a
            if new_dim <= 0:
                raise ValueError(f"empty slice [{a}:{b})")
                
            return VectorExpr({
                v: c[a:b] for v, c in self.coef_map.items()
            })

        if isinstance(key, str):
            if self.dim == 0:
                return GF2(0)
            return self.coef_map.get(key, zero_vector(GF2, self.dim))

        else:
            try:
                key = int(key)
                if key == 1: # special case: get constant :)
                    return self.coef_map.get('1', zero_vector(GF2, self.dim))
            except ValueError:
                pass
                
        raise TypeError(f"index must be a slice or str or 1, got {type(key)}")
        
    # ---------------------------------------------------------------- evaluation

    def __call__(self, repl: dict[IntExpr, IntExpr]):
        """
        Replace an expression with another:
                        x |-> z               maps
            (1, 0, 1) * x |-> (1, 0, 1) * z
        """
        
        if not isinstance(repl, dict):
            raise TypeError("repl must be a dictionary")
        
        if not repl:
            return VectorExpr(self.coef_map)

        call_result = VectorExpr(self.coef_map)
        
        for expr in repl:
            expr_vars = set( v for v, c in expr.coef_map.items() if c != 0 )
            # expr_cofs = [ expr[v]                 for v in expr_vars ]
            self_cofs = [ call_result.coef_map.get(v, 0) for v in expr_vars ]

            if len(expr_vars) == 0:
                raise ValueError("cannot replace something out of nothing")

            # this check is necessary because i don't like branches :)
            if len(expr_vars) > 1:
                if not all(self_cof == self_cofs[0] for self_cof in self_cofs[1:]): # cheating bc we're in GF(2) :)
                    raise ValueError(f"cannot replace this expression: {expr} with {repl[expr]}")

            # nothing to replace here :)
            if self_cofs[0] == 0:
                continue

            repl_expr = repl[expr]
            repl_vars = set( v for v, c in repl_expr.coef_map.items() if c != 0 )
            if expr_vars & repl_vars:
                raise ValueError("sorry this tech is primitive, no recursion allowed :(")

            for expr_var in expr_vars:
                del call_result.coef_map[expr_var] # or set to 0
            for repl_var in repl_vars:
                repl_cof = call_result.coef_map.get(repl_var, 0) + self_cofs[0]
                if repl_cof != 0:
                    call_result.coef_map[repl_var] = repl_cof
                elif repl_var in call_result.coef_map:
                    del call_result.coef_map[repl_var]

        return VectorExpr(call_result.coef_map)
                
    
    # ----------------------------------------------------------------- display

    @staticmethod
    def repr_var_cmp(x):
        if len(x[0].split('_')) != 2:
            return (3, 0, 0, x[0])

        fields = x[0].split('_')
        try:
            field1 = int(fields[0][1:])
            field2 = int(fields[1])
        except ValueError:
            return (3, 0, 0, x[0])
        
        if fields[0][0] == 'S':
            return (1, field1, field2, "")
        elif fields[0][0] == 'O':
            return (2, field1, field2, "")
        return (3, field1, field2, x[0])
    
    def __repr__(self):
        if not self.coef_map:
            return "0"

        """
            {coef0} * var0
          + {coef1} * var1
          + {coef2} * var2
        """
        vars_and_coefs = sorted(self.coef_map.items(), key=self.repr_var_cmp)
        
        var_map = {}
        for var, coef in vars_and_coefs:
            if f"{coef}" not in var_map:
                var_map[f"{coef}"] = [var]
            else:
                var_map[f"{coef}"].append(var)

        disp = "    "
        for coef, vars_ in var_map.items():
            coef = coef.split(', ')
            disp += f'{" ".join(map(str, coef))} * '
            if len(vars_) <= 1:
                disp += f' {vars_[0]}'
            else:
                disp += "(" + " + ".join(vars_) + ")"
            disp += "\n  + "
        
        return disp[:-5]
        
    def __eq__(self: 'VectorExpr', other: 'VectorExpr | int'):
        if not isinstance(other, VectorExpr):
            if other != 0:
                raise TypeError(f'invalid comparison of VectorExpr with {type(other)}')
            return len(self.coef_map) == 0

        if self.coef_map.keys() != other.coef_map.keys():
            return False

        for var, coef in self.coef_map.items():
            if coef != other.coef_map.get(var, None):
                return False

        return True
