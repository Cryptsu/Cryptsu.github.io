from sage.all import GF

GF2 = GF(2)

class IntExpr:
    def __init__(self, coef_map: dict[str, int] = {}):
        self.coef_map = {}
        for var, coef in coef_map.items():
            if coef == 0:
                continue
            try:
                coef = GF2(coef)
            except TypeError:
                raise ValueError(f"coef must be in GF(2), got {type(coef)}")
            self.coef_map[var] = coef

    def __add__(self, other: 'IntExpr'):
        if not isinstance(other, IntExpr):
            raise ValueError(f"adding IntExpr with non IntExpr (got {type(other)}) is not allowed")

        sum_map = {}
        for var, coef in self.coef_map.items():
            sum_map[var] = coef
        for var, coef in other.coef_map.items():
            sum_map[var] = sum_map.get(var, GF2(0)) + coef

        return IntExpr(sum_map)

    def __sub__(self, other: 'IntExpr'):
        return self.__add__(other)

    def __repr__(self):
        if not self.coef_map:
            return "0"
        disp = ""
        for var, coef in self.coef_map.items():
            # if coef == 0:
            #     continue
            # disp += f'{coef} * {var} + '
            disp += f'{var} + '
        return disp[:-3]

    def __eq__(self: 'IntExpr', other: 'IntExpr | int'):
        if not isinstance(other, IntExpr):
            if other != 0:
                raise TypeError(f'invalid comparison of IntExpr with {type(other)}')
            return len(self.coef_map) == 0

        # GF(2) only need variables ;)
        if self.coef_map.keys() != other.coef_map.keys():
            return False

        for var, coef in self.coef_map.items():
            if coef != other.coef_map.get(var, None):
                return False

        return True

    def __hash__(self: 'IntExpr') -> int:
        return hash(tuple(self.coef_map.keys())) # GF(2) only need variables ;)
